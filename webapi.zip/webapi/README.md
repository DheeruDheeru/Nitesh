# aspnet-core-jwt-authentication-api

ASP.NET Core 2.2 - JWT Authentication API

For documentation and instructions check out http://jasonwatmore.com/post/2018/08/14/aspnet-core-21-jwt-authentication-tutorial-with-example-api
