﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NiteshSharma.Helper
{
    public class AppSettings
    {
        public string TokenKey { get; set; }
    }
}
